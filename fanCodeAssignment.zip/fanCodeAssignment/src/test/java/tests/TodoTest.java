package tests;

import com.practice.service.FanCodeService;
import com.practice.service.FanCodeUser;
import com.practice.service.UserService;
import org.testng.annotations.Test;

import java.util.List;
import java.util.Map;
import static org.testng.Assert.assertTrue;


public class TodoTest {

    @Test(description = "Validate that users from the FanCode city have more than 50% completion of tasks")
    public void testFanCodeTodoTasks() {
        List<Map<String, Object>> users = UserService.getUsers();
        List<Integer> fancodeUserIds = FanCodeUser.usersBelongFanCodeCity(users);
        System.out.println("FanCodeuser users who belongs to fanCode city : "+ fancodeUserIds);
        fancodeUserIds.forEach(userId -> {
            List<Map<String, Object>> todos = FanCodeService.getTodosForUser(userId);
            System.out.println("Todos users: "+todos);
            double completedPercentage = FanCodeService.calculateCompletionPercentage(todos);

            assertTrue(completedPercentage > 50, "User " + userId + " should have more than 50% completed todos");
        });

        System.out.println("All FanCode users have more than 50% of their todos completed.");
    }
}