package com.practice.model;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;

@Data
@Builder
@Getter
public class Post {
    private int userId;
    private int id;
    private String title;
    private String body;

}
