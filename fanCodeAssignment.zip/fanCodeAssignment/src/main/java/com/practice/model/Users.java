package com.practice.model;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;

@Data
@Builder
@Getter

public class Users {
    public int id;
    public String name;
    public String username;
    public String email;
    public Address address;
    @Data
    @Builder
    @Getter
    public static class Address {
        public String street;
        public String suite;
        public String city;
        public String zipcode;
        public Geo geo;
    }
    @Data
    @Builder
    @Getter
    public static class Geo {
        public String lat;
        public String lng;
    }

}
