package com.practice.model;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;

@Data
@Builder
@Getter
@JsonIgnoreProperties(ignoreUnknown = true)

public class Todo {
    public int userId;
    public int id;
    public String title;
    public boolean completed;
}
