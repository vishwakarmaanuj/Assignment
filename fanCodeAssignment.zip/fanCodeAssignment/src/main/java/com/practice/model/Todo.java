package com.practice.model;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;

@Data
@Builder
@Getter

public class Todo {
    public int userId;
    public int id;
    public String title;
    public boolean completed;
}
