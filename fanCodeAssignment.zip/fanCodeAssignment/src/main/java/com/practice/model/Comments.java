package com.practice.model;

//import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;

@Data
@Builder
@Getter
//@JsonIgnoreProperties(ignoreUnknown = true)
public class Comments {
    private int postId;
    private int id;
    private String name;
    private String email;
    private String body;

}
