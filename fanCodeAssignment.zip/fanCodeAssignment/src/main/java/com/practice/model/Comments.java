package com.practice.model;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;

@Data
@Builder
@Getter
public class Comments {
    private int postId;
    private int id;
    private String name;
    private String email;
    private String body;

}
