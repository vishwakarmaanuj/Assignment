package com.practice.model;

//import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;

@Data
@Builder
@Getter
//@JsonIgnoreProperties(ignoreUnknown = true)
public class Photos {

    private int albumId;
    private int id;
    private String title;
    private String url;
    private String thumbnailUrl;

}
