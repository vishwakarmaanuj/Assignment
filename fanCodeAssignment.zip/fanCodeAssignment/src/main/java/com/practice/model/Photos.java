package com.practice.model;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;

@Data
@Builder
@Getter
public class Photos {

    private int albumId;
    private int id;
    private String title;
    private String url;
    private String thumbnailUrl;

}
