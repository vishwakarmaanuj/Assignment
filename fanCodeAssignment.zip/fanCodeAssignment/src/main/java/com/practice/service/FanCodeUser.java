package com.practice.service;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class FanCodeUser {
    public static List<Integer> usersBelongFanCodeCity(List<Map<String, Object>> users) {
        return users.stream()
                .filter(FanCodeUser::isFanCodeUser)
                .map(user -> (Integer) user.get("id"))
                .collect(Collectors.toList());
    }

    private static boolean isFanCodeUser(Map<String, Object> user) {
        Map<String, String> geo = (Map<String, String>) ((Map<String, Object>) user.get("address")).get("geo");
        double lat = Double.parseDouble(geo.get("lat"));
        double lng = Double.parseDouble(geo.get("lng"));
        return lat >= -40 && lat <= 5 && lng >= 5 && lng <= 100;
    }

}
