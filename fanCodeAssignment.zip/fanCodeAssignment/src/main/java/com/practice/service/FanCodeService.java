package com.practice.service;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import java.util.List;
import java.util.Map;

import static io.restassured.RestAssured.given;

public class FanCodeService {
    public  static List<Map<String, Object>> getTodosForUser(int userId) {
        Response todosResponse = given()
                .contentType(ContentType.JSON)
                .log().all()
                .when()
                .get("/todos?userId=" + userId)
                .then()
                .extract()
                .response();

        return todosResponse.jsonPath().getList("$");
    }

    public static double calculateCompletionPercentage(List<Map<String, Object>> todos) {
        long totalTodos = todos.size();
        long completedTodos = todos.stream()
                .filter(todo -> (Boolean) todo.get("completed"))
                .count();
        System.out.println(" Total todos :"+ totalTodos);
        System.out.println("completed todos: "+ completedTodos);
        return ((double) completedTodos / totalTodos) * 100;

    }
}
