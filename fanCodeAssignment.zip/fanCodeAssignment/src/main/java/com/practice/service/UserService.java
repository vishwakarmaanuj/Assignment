package com.practice.service;


import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

import java.util.List;
import java.util.Map;

import static io.restassured.RestAssured.given;

public class UserService {

    public static List<Map<String, Object>> getUsers() {
        RestAssured.baseURI = "http://jsonplaceholder.typicode.com";
        Response usersResponse = given()
                .contentType(ContentType.JSON)
                .log().all()
                .when()
                .get("/users")
                .then()
                .extract()
                .response();

        return usersResponse.jsonPath().getList("$");
    }
}
